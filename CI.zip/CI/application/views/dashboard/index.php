
  


<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css')?>">
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.js')?>"></script>


<!-- Navigation bar -->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Ecommerce</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="<?php echo base_url('User/logout'); ?>"> Log Out </a>
    </ul>
  </div>
</nav>

<!-- CARDS --->
<div class="container">
    <div class="jumbotron">
       <h3 style="text-align: center;">Welcome to <?php echo $title ?></h3>
    </div>

<div style="display: flex;margin-bottom: 50px;">
<div class="card" style="width: 33%;">
<img class="imgClass" src="<?php echo site_url('assets/images/laptop.jpg'); ?>" />
  <div class="card-body" style="text-align: center;">
    <h5 class="card-title"><b>Lenovo Laptops</b></h5>
    <p class="card-text">All brands laptops are available currently and offers available till this month.</p>
    <a href="#" class="btn btn-primary">Available</a>
  </div>
</div>
<div class="card" style="width: 33%;margin-left: 60px;">
  <img class="imgClass" src="<?php echo site_url('assets/images/tv.jpg'); ?>" />
  <div class="card-body" style="text-align: center;">
    <h5 class="card-title"><b>Samsung Tv</b></h5>
    <p class="card-text">All brands laptops are available currently and offers available till this month.</p>
    <a href="#" class="btn btn-primary">Available</a>
  </div>
</div>
<div class="card" style="width: 33%;margin-left: 60px;">
  <img class="imgClass" src="<?php echo site_url('assets/images/mobile2.jpg'); ?>" />
  <div class="card-body" style="text-align: center;">
    <h5 class="card-title"><b>Samsung Mobiles</b></h5>
    <p class="card-text">All brands laptops are available currently and offers available till this month.</p>
    <a href="#" class="btn btn-primary">Available</a>
  </div>
</div>
</div>
<div style="display: flex;">
<div class="card" style="width: 33%;">
<img class="imgClass" src="<?php echo site_url('assets/images/laptop.jpg'); ?>" />
  <div class="card-body" style="text-align: center;">
    <h5 class="card-title"><b>Lenovo Laptops</b></h5>
    <p class="card-text" >All brands laptops are available currently and offers available till this month.</p>
    <a href="#" class="btn btn-primary">Available</a>
  </div>
</div>
<div class="card" style="width: 33%;margin-left: 60px;">
  <img class="imgClass" src="<?php echo site_url('assets/images/tv.jpg'); ?>" />
  <div class="card-body" style="text-align: center;">
    <h5 class="card-title"><b>Samsung Tv</b></h5>
    <p class="card-text">All brands laptops are available currently and offers available till this month.</p>
    <a href="#" class="btn btn-primary">Available</a>
  </div>
</div>
<div class="card" style="width: 33%;margin-left: 60px;">
  <img class="imgClass" src="<?php echo site_url('assets/images/mobile2.jpg'); ?>" />
  <div class="card-body" style="text-align: center;">
    <h5 class="card-title"><b>Samsung Mobiles</b></h5>
    <p class="card-text">All brands laptops are available currently and offers available till this month.</p>
    <a href="#" class="btn btn-primary">Available</a>
  </div>
</div>
</div>

</div>
<!-- Footer -->
<footer class="page-footer font-small blue">

  
  <div class="footer-copyright text-center py-3" style="font-size: 20px; padding-top: 4%;">© 2020 Copyright:
    <a style="color: white;" href="<?php echo base_url('dashboard'); ?>"> <b>Go to Site</b> </a>
  </div>
 

</footer>

