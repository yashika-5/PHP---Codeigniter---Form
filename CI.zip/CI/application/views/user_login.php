



<!--<div class="container">
<form method="post" name="form" action="">
  <div class="form-group">
    <label for="exampleInputUsername">Username</label>
    <input type="text" name="username" class="form-control" id="exampleInputUsername">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1">
  </div>
  
  <button type="submit" name="log" class="btn btn-primary">Submit</button>
</form>
</div>-->

<!DOCTYPE html>
<html>
<head>
<title>Login form</title>

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css')?>">
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.js')?>"></script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>


<style type="text/css">
          .container
          {
               position: absolute;
               left: 50%;
               top: 50%;
               transform: translate(-50%,-50%);
               padding: 20px 25px;
               width: 400px;
               background-color: rgba(0,0,0,.7);
               box-shadow: 0 0 10px rgba(255,255,255,.3);   
          }
          html{
    background-color: lightslategray;
}
</style>


</head>


<body>

  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#" style="color: thistle;">Ecommerce</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a  style="color: thistle;" href="<?php echo base_url('User/login'); ?>"> Log in </a>
    </ul>
  </div>
</nav>


<div class="container">
    <h1 style="text-align: center;margin-bottom: 30px;color: thistle;"><?php echo $title ?></h1>
    <form method="post" action="login">   
        <p>
        <input type="text" class="form-control"  name="uname" placeholder="Username" required>
        </p>         
        <p>
        <input type="password" class="form-control" name="pass" placeholder="Password" required>
        </p>
        <p>
        <button type="submit" name="login" class="btn btn-primary" value="Login">Submit</button>
       </p>
    </form>
    <?php if($this->session->flashdata('message')) { ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('message')?>
            </div>
   <?php } ?>
</div>
</body>
</html>