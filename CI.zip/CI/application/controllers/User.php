<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller
{
   public function __construct()
   {
     parent::__construct();
    $this->load->helper('url');
    $this->load->helper('form');
    $this->load->library('session');
     $this->load->library('form_validation');
     $this->load->model('user_model');
   }

   private function logged_in()
    {
        if( ! $this->session->userdata('authenticated')){
            redirect('User/login');
        }
    }


    public function login()
    {
        $data['title'] = "LOGIN";
        
        $this->form_validation->set_rules('uname', 'username', 'trim|required');
        $this->form_validation->set_rules('pass', 'password', 'required');
      
        if($this->form_validation->run() == false)
        {           
            $this->load->view('user_login', $data);        
        } 
        else 
        {
            $u = $this->security->xss_clean($this->input->post('uname'));
            $p = $this->security->xss_clean($this->input->post('pass'));
            
            $user = $this->user_model->login($u, $p);
            
            if($user){

                   $this->session->set_userdata(array( 'authenticated' => true));                
                   redirect('Dashboard');
            }
            else {
                $this->session->set_flashdata('message', 'Invalid email or password');
                redirect('User/login');
            }
        }
    }

    
    public function logout()
    {
        $this->session->sess_destroy();
        redirect('User/login');
    }
}
?>